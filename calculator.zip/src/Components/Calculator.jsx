import React, { useState } from 'react'
import "./Calculator.css"
const Calculator = () => {

    const [input, setInput] = useState("");

  const handleClick = (value) => {
    setInput((prev) => prev + value);
  };

  const clearInput = () => {
    setInput("");
  };

  const calculateResult = () => {
    try {
      setInput(eval(input).toString()); 
    } catch (error) {
      setInput("Error");
    }
  };
  return (
    <>

    <div className="calculator">
        <h1>Calculator</h1>
    <input type="text" value={input} readOnly />
    <div className="buttons">
      <button onClick={clearInput} className="clear">C</button>
      {["7", "8", "9", "/"].map((btn) => (
        <button key={btn} onClick={() => handleClick(btn)}>{btn}</button>
      ))}
      {["4", "5", "6", "*"].map((btn) => (
        <button key={btn} onClick={() => handleClick(btn)}>{btn}</button>
      ))}
      {["1", "2", "3", "-"].map((btn) => (
        <button key={btn} onClick={() => handleClick(btn)}>{btn}</button>
      ))}
      {["0", ".", "+", "="].map((btn) => (
        btn === "=" ? (
          <button key={btn} onClick={calculateResult} className="equal">{btn}</button>
        ) : (
          <button key={btn} onClick={() => handleClick(btn)}>{btn}</button>
        )
      ))}
    </div>
  </div>
  </>
);
};


 

export default Calculator